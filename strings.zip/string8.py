user_string = input('enter some text')
print(user_string)
user_string_isalnum = user_string.isalnum()
print(user_string.isalnum())