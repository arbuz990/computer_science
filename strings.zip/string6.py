user_string = input('enter some text')
print(user_string)
user_string_islower = user_string.islower()
print(user_string.islower())