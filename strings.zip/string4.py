user_string = input('enter some text')
print(user_string)
user_string_find_case = user_string.find('home')
print(user_string.find('home'))