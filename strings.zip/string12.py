user_string = input('enter some text')
print(user_string)
user_string_strip = user_string.strip('x')
print(user_string.strip('x'))