user_string = input('enter some text')
print(user_string)
user_string_replace = user_string.replace('h','e')
print(user_string.replace('h','e'))