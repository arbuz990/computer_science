user_string = input('enter some text')
print(user_string)
user_string_isdigit = user_string.isdigit()
print(user_string.isdigit())