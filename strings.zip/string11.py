user_string = input('enter some text')
print(user_string)
user_string_index = user_string.index('x')
print(user_string.index('x'))