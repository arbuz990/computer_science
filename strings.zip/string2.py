user_string = input('enter some text')
print(user_string)
user_string_upper_case = user_string.lower()
print(user_string.lower())