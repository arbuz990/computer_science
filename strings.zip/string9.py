user_string = input('enter some text')
print(user_string)
user_string_isalpha = user_string.isalpha()
print(user_string.isalpha())