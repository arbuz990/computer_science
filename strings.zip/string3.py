user_string = input('enter some text')
print(user_string)
user_string_count_case = user_string.count('h')
print(user_string.count('h'))

