user_string = input('enter some text')
print(user_string)
user_string_isupper = user_string.isupper()
print(user_string.isupper())