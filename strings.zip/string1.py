user_string = input('enter some text: ')
print(user_string)
user_string_title_case = user_string.upper()
print(user_string.upper())


